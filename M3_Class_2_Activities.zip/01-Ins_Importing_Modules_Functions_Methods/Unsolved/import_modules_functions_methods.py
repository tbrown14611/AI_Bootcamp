"""Importing  modules, functions and methods"""

# Import the sqrt function from the math module.


# Calculate the square root of a number.


# Import the randint and choice methods from the random module.

# Generate a random number between 1 and 10 and selecting a random element from a list.


# Use the choice method to randomly select an element from the list.

# Import the datetime and date classes from the datetime module.

# Get the current datetime using the now function.


# Get the current time using the strftime function.

# Get the current date using the today function.


