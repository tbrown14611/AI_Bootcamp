# ATM User Stories

With your group, use the space below to pseudocode some examples for the ATM user stories:

  * As a user of an ATM, I: **input my PIN for identification.**

  * As a user of an ATM, I: **identify whether I’m going to make a deposit or withdrawal.**

  * As a user of an ATM, I: **input the amount of my deposit or withdrawal.**

  * As a user of an ATM, I: **receive cash.**

  * As a user of an ATM, I: **deposit cash and checks.**

  * As a user of an ATM, I: **want to receive my adjusted account balance.**

---

© 2023 edX Boot Camps LLC. Confidential and Proprietary. All Rights Reserved.
