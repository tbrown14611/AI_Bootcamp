"""Refactoring Examples"""

# Code using for loop.


# Refactored the code to use a list comprehension

# Code that uses the range() function.

# Refactored the code to use enumerate()

# Code without a function.

# Refactored code with a function
