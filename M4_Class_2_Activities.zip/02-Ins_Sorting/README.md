# Instructor Do

# Sorting
Data Source: Vermont Agency of Administration, Department of Taxes. Meals and Rooms Tax Statistics (2020 Multiple Periods Update, Calendar Year). [https://tax.vermont.gov/data-and-statistics/mrt](https://tax.vermont.gov/data-and-statistics/mrt)

## Reference
Vermont Agency of Administration, Department of Taxes. 2020. Meals and Rooms Tax Statistics (2020 Multiple Periods Update, Calendar Year) [Dataset]. Available: [https://tax.vermont.gov/data-and-statistics/mrt](https://tax.vermont.gov/data-and-statistics/mrt).

---

© 2023 edX Boot Camps LLC. Confidential and Proprietary. All Rights Reserved.
