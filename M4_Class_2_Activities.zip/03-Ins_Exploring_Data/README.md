# Instructor Do

## Reference

Federal Election Commission. 2021. Contributions by individuals, 2021-2022 [Dataset]. Available: [Federal Election Commission](https://www.fec.gov/data/browse-data/?tab=bulk-data). Data extracted, reduced, and modified in Pandas.



---

© 2023 edX Boot Camps LLC. Confidential and Proprietary. All Rights Reserved.
