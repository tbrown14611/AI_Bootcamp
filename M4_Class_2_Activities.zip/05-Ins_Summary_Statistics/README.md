# Instructor Do

### Resources

NOAA National Centers for Environmental information, Climate Data Online. [https://www.ncei.noaa.gov/products/land-based-station/us-climate-normals](https://www.ncei.noaa.gov/products/land-based-station/us-climate-normals)

---

© 2023 edX Boot Camps LLC. Confidential and Proprietary. All Rights Reserved.
