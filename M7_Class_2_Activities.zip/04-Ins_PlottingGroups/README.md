# Instructor Demo

## Reference

National Highway Traffic Safety Administration. 2019. *National Accidents - Fatality Analysis Reporting System*. Available: [https://www.nhtsa.gov/file-downloads?p=nhtsa/downloads/FARS/2019/National/](https://www.nhtsa.gov/file-downloads?p=nhtsa/downloads/FARS/2019/National/)


- - -

© 2023 edX Boot Camps LLC. Confidential and Proprietary. All Rights Reserved.
