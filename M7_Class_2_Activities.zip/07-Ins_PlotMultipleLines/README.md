# Instructor Demo

## Reference

International Labour Organization. 2021. *Unemployment, total (% of total labor force) (modeled ILO estimate)*. ILOSTAT database. Available: [https://data.worldbank.org/indicator/SL.UEM.TOTL.ZS](https://data.worldbank.org/indicator/SL.UEM.TOTL.ZS) [Retrieved June 15, 2021]. ([CC-BY 4.0](https://creativecommons.org/licenses/by/4.0/legalcode)).


- - -

© 2023 edX Boot Camps LLC. Confidential and Proprietary. All Rights Reserved.
