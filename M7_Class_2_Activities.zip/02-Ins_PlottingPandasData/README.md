# Instructor Demo

## Reference

Palecki, M., Durre, I., Lawrimore, J., & Applequist, S. 2021. *U.S. Annual/Seasonal Climate Normals (2006-2020)*. National Centers for Environmental Information, National Oceanic and Atmospheric Administration. Available: [https://www.ncei.noaa.gov/metadata/geoportal/rest/metadata/item/gov.noaa.ncdc%3AC01623/html](https://www.ncei.noaa.gov/metadata/geoportal/rest/metadata/item/gov.noaa.ncdc%3AC01623/html). N.B. This data was downloaded, combined, reduced, and calculated in Pandas.




- - -

© 2023 edX Boot Camps LLC. Confidential and Proprietary. All Rights Reserved.
