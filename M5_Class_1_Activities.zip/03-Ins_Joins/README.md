# Instructor Demo

## Reference

OECD and Food and Agriculture Organization of the United Nations. 2023. *OECD-FAO Agricultural Outlook*. DOI:  [10.1787/08801ab7-en](https://doi.org/10.1787/08801ab7-en)


---

© 2023 edX Boot Camps LLC. Confidential and Proprietary. All Rights Reserved.
