# Instructor Demo

## Reference

The World Data Bank. (2021) World Development Indicators. [https://datacatalog.worldbank.org/search/dataset/0037712/World-Development-Indicators](https://datacatalog.worldbank.org/search/dataset/0037712/World-Development-Indicators), reduced in pandas.

- - -

© 2023 edX Boot Camps LLC. Confidential and Proprietary. All Rights Reserved.
