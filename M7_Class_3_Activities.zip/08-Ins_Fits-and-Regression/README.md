# Instructor Demo

## References

[Scikit-learn’s California housing dataset](https://scikit-learn.org/stable/modules/generated/sklearn.datasets.fetch_california_housing.html)

[Scikit-learn diabetes dataset](https://scikit-learn.org/stable/datasets/toy_dataset.html#diabetes-dataset) originally sourced from https://www4.stat.ncsu.edu/~boos/var.select/diabetes.html - Bradley Efron, Trevor Hastie, Iain Johnstone and Robert Tibshirani (2004) “Least Angle Regression,” Annals of Statistics (with discussion), 407-499. (https://web.stanford.edu/~hastie/Papers/LARS/LeastAngle_2002.pdf)

- - -

© 2023 edX Boot Camps LLC. Confidential and Proprietary. All Rights Reserved.
