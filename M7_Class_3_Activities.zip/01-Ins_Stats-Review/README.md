# Instructor Demo

## Reference

*NOAA National Centers for Environmental Information*. 2023. *Climate Data Online* [Dataset]. Available: [https://www.ncei.noaa.gov/products/land-based-station/us-climate-normals](https://www.ncei.noaa.gov/products/land-based-station/us-climate-normals) [2023].




- - -

© 2023 edX Boot Camps LLC. Confidential and Proprietary. All Rights Reserved.
