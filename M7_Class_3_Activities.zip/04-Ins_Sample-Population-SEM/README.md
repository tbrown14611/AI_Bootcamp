# Instructor Demo

## Reference

U.S. Department of Energy Office of Energy Efficiency and Renewable Energy. (2019). Fuel Economy Guide Model Year 2019.[https://www.fueleconomy.gov/feg/download.shtml](https://www.fueleconomy.gov/feg/download.shtml)

- - -

© 2023 edX Boot Camps LLC. Confidential and Proprietary. All Rights Reserved.
