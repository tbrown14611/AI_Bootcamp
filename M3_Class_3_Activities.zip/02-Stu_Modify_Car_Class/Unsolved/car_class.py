"""Creating a Car class with methods and instances"""

# Define the Car class
class Car:
    """Creating a Car class with 6 parameters and instances"""


# Prompt the user to enter the information for the car for each parameter.
# Hint: Make sure the year is an integer.

# Create an instance of the `Car` class and pass in the variables from the user.
car = Car()

# Print the details of the car
print('Here is the information you enter for the car.')
