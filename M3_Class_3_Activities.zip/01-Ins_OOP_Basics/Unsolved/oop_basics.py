"""Creating a Car class with parameters and instances"""

# Define the Car class
class Car:
    """Creating a Car class with parameters"""



# Create an instance of the Car class using the user's input

# Print the details of the car
